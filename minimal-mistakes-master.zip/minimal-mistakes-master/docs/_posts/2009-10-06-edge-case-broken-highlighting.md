---
title: "Edge Case: Invalid syntax highlight languages"
categories:
  - Edge Case
tags:
  - content
  - css
  - edge case
---

Good highlighting:

```ruby
str = ARGV.first
if str
  str = str.b[/\A_(.*)_\z/, 1]
  if str and Gem::Version.correct?(str)
    version = str
    ARGV.shift
  end
end
```

Good (but dumb) highlighting:

```
str = ARGV.first
if str
  str = str.b[/\A_(.*)_\z/, 1]
  if str and Gem::Version.correct?(str)
    version = str
    ARGV.shift
  end
end
```

Bad highlighting:

```invalid
str = ARGV.first
if str
  str = str.b[/\A_(.*)_\z/, 1]
  if str and Gem::Version.correct?(str)
    version = str
    ARGV.shift
  end
end
```
